<!-----------------Footer Part -------------------->
	<footer>
			<div class="container">
				<div class="logo pull-left">
							<img src="images/Logo.png" alt="LOGO" />
						</div>
			</div>

	</footer>