			<!------------Top Bar -------------->
			<div class="top-bar">
				<div class="container">
						<div class="logo pull-left">
							<img src="images/Logo.png" alt="LOGO" />
						</div>
						<div class="account-credentials pull-right">
							<ul>
								<li><a href="#"><i class="fa fa-comments" aria-hidden="true"></i></a></li>
								<li><a href="#"><i class="fa fa-bell" aria-hidden="true"></i></a></li>
								<li><a href="#"><i class="fa fa-question-circle" aria-hidden="true"></i></a></li>
								<li><a href="#"><i class="fa fa-cogs" aria-hidden="true"></i></i></a></li>
								<li><a href="{{ route('logout') }}" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><i class="fa fa-sign-out" aria-hidden="true"></i></a></li>
                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                            {{ csrf_field() }}
                                    </form>
							</ul>
						</div>
				</div>
			</div>

			<!------------Navigation Bar -------------->
			<div class="main-nav">
				<div class="container">
					<nav class="navbar navbar-expand-lg navbar-light">
					  
					  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
					    <span class="navbar-toggler-icon"></span>
					  </button>
					  <div class="collapse navbar-collapse" id="navbarNav">
					    <ul class="navbar-nav">
					      <li class="nav-item">
					        <a class="nav-link active" href="#">Summary <span class="sr-only">(current)</span></a>
					      </li>
					      <li class="nav-item">
					        <a class="nav-link" href="#">Sales</a>
					      </li>
					      <li class="nav-item">
					        <a class="nav-link" href="#">Cashbook</a>
					      </li>
					      <li class="nav-item">
					        <a class="nav-link" href="#">Contacts</a>
					      </li>
					      <li class="nav-item">
					        <a class="nav-link" href="#">Banking</a>
					      </li>
					      <li class="nav-item">
					        <a class="nav-link" href="#">Reports</a>
					      </li>
					    </ul>
					  </div>
					</nav>
				</div>
			</div>	
