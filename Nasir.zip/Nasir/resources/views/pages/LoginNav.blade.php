			<div class="top-bar">
				<div class="container">
						<div class="logo pull-left">
							<img src="images/Logo.png" alt="LOGO" />
						</div>
						<div class="account-credentials pull-right">
							<ul>
								<li><a href="{{ route('login') }}">Login</a></li>
								<li><a href="{{ route('register') }}">Register</a></li>
							</ul>
						</div>
				</div>
			</div>