@extends('layouts.Dashboard')

@section('content')
<!-----------------Summary Blocks-------------------->  
            <div class="container">
                <div class="row mr-23">
                        <div class="col-md-4 cards">
                            <div class="summary-card">
                                    <div class="card-heading">
                                        <h2>Money in</h2>

                                    </div>
                                    <div class="card-content">
                                        <h2>$0.00</h2>
                                        <span class="card-tagline">this month</span>
                                    </div>
                            </div>
                        </div>
                        <div class="col-md-4 cards">
                            <div class="summary-card">
                                    <div class="card-heading">
                                        <h2>Money out</h2>

                                    </div>
                                    <div class="card-content">
                                        <h2>$0.00</h2>
                                        <span class="card-tagline">this month</span>
                                    </div>
                            </div>
                        </div>
                        <div class="col-md-4 cards">
                            <div class="summary-card">
                                    <div class="card-heading">
                                        <h2>Balance</h2>

                                    </div>
                                    <div class="card-content">
                                        <h2>$0.00</h2>
                                        <span class="card-tagline">this month</span>
                                    </div>
                            </div>
                        </div>
                </div>
                <div class="row mr-30">
                        <div class="col-md-4 cards">
                            <div class="summary-card">
                                    <div class="card-heading">
                                        <h2>Invoices</h2>

                                    </div>
                                    <div class="card-content">
                                        <h2>$0.00</h2>
                                        <span class="card-tagline">this month</span>
                                    </div>
                            </div>
                        </div>
                        <div class="col-md-4 cards">
                            <div class="summary-card">
                                    <div class="card-heading">
                                        <h2>Customers by outstanding invoices</h2>

                                    </div>
                                    <div class="card-content">
                                        <h2>$0.00</h2>
                                        <span class="card-tagline">this month</span>
                                    </div>
                            </div>
                        </div>
                        <div class="col-md-4 cards">
                            <div class="summary-card">
                                    <div class="card-heading">
                                        <h2>customers by overdue invoices</h2>

                                    </div>
                                    <div class="card-content">
                                        <h2>$0.00</h2>
                                        <span class="card-tagline">this month</span>
                                    </div>
                            </div>
                        </div>
                </div>
                <div class="row mr-30">
                        <div class="col-md-4 cards">
                            <div class="summary-card">
                                    <div class="card-heading">
                                        <h2>Baking</h2>

                                    </div>
                                    <div class="card-content">
                                        <h2>$0.00</h2>
                                        <span class="card-tagline">this month</span>
                                    </div>
                            </div>
                        </div>
                        
                        
                </div>
            </div>
@endsection
