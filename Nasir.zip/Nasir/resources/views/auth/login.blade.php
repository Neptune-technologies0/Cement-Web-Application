@extends('layouts.Login')

@section('content')
        <form method="POST" action="{{ route('login') }}">
            {{ csrf_field() }}
                    <div class="col-md-12">
                        <div class="login-form">
                            <h2><span>Nep</span>tech</h2>
                            
                           <div class="form-group">
                                          <label for="usr">Name:</label>
                                          <input id="email" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') }}" required autofocus>
                                            @if ($errors->has('email'))
                                                <span class="invalid-feedback">
                                                    <strong>{{ $errors->first('email') }}</strong>
                                                </span>
                                            @endif
                            </div>
                            <div class="form-group">
                                          <label for="pwd">Password:</label>
                                          <input id="password" type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" required>

                                            @if ($errors->has('password'))
                                                <span class="invalid-feedback">
                                                    <strong>{{ $errors->first('password') }}</strong>
                                                </span>
                                            @endif
                            </div>
                            <div class="form-group">
                                    <div class="form-check">
                                        <label>
                                            <input type="checkbox" name="remember" {{ old('remember') ? 'checked' : '' }}> <span class="label-text">Remember me</span>
                                        </label>
                                    </div>
                            </div>

                            <div class="form-group">
                                          <button type="submit" class="btn btn-success btn-block">Login</button>
                            </div>                      
                    </div>
                </div>
            </form><!---form End---->
            <div class="forget-form">
                    <div class="col-md-12">
                            <a href="{{ route('password.request') }}">Forgot your password?</a>
                    </div>
            </div>
    
@endsection
