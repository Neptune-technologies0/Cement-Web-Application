@extends('layouts.Login')
@section('content') 
        <form method="POST" action="{{ route('register') }}">
            {{ csrf_field() }}
                    <div class="col-md-12">
                        <div class="login-form">
                            <h2><span>Nep</span>tech</h2>
                            
                            <div class="form-group">
                                          <label for="usr">Name:</label>
                                          <input id="name" type="text" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" value="{{ old('name') }}" required autofocus>
                                            @if ($errors->has('name'))
                                                <span class="invalid-feedback">
                                                    <strong>{{ $errors->first('name') }}</strong>
                                                </span>
                                            @endif
                            </div>
                            <div class="form-group">
                                          <label for="usr">E-Mail Address:</label>
                                          <input id="email" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') }}" required>
                                            @if ($errors->has('email'))
                                                <span class="invalid-feedback">
                                                    <strong>{{ $errors->first('email') }}</strong>
                                                </span>
                                            @endif
                            </div>
                             <div class="form-group">
                                          <label for="pwd">Password:</label>
                                          <input id="password" type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" required>
                                            @if ($errors->has('password'))
                                                <span class="invalid-feedback">
                                                    <strong>{{ $errors->first('password') }}</strong>
                                                </span>
                                            @endif
                            </div>
                            <div class="form-group">
                                          <label for="pwd">Confirm Password:</label>
                                          <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                            <div class="form-group">
                                          <button type="submit" class="btn btn-success btn-block">Register</button>
                            </div>                      
                    </div>
                </div>
            </form>
            <div class="forget-form">
                    <div class="col-md-12">
                            <a href="{{ route('login') }}">Go Back To Login Page?</a>
                    </div>
            </div>  
@endsection