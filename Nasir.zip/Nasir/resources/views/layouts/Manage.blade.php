<!DOCTYPE html>
<html>
<head>
	<title>Web Applicaiton</title>

	<!----------------------Meta ------------------>
	
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<!------------------------------------------------------------------>

	<link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap.min.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ asset('css/dataTables.bootstrap4.min.Css') }}">
	<!------------------------------------------------------------------>


	<!----------------------Main Css ------------------>	
	<!---<link href="{{ asset('css/app.css') }}" rel="stylesheet">-->
	<link rel="stylesheet" type="text/css" href="{{ asset('css/font-awesome.min.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ asset('css/main.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ asset('css/sale.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ asset('css/DataTable.css')}}">

	@yield('mycustomcss')
</head>
<body>
				<!-----------------Header Part -------------------->
				<header>
						@include("pages.mainNav")
				</header>
				<!------Header Navigation ---->



				<!-----main-------->
				<main>
						@yield('content')

				</main>
				<!------main End-------->
				@include("pages.footer")
				
	<script src="{{ asset('js/app.js') }}"></script>
	<script src="{{ asset('js/bootstrap.min.js') }}"></script>
	<script src="{{ asset('js/jquery.dataTables.min.js') }}"></script>
	<script src="{{ asset('js/dataTables.bootstrap4.min.js') }}"></script>
	@yield('mycustomscripts')
</body>

</html>