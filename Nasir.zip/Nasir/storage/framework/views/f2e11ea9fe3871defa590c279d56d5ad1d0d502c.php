	<!-----------------Top BreadCums -------------------->
				<div class="Dashboard-breadcum">
					<div class="container">
						<div class="dashboard-heading pull-left">
								<h2>Dashboard</h2>
								<span class="tagline">Welcome back, <?php echo e(Auth::user()->name); ?></span>
						</div>
						<div class="dashboard-button pull-right">
								<a href="#"><i class="fa fa-plus" aria-hidden="true"></i> New Invoice</a>
						</div>
					</div>
				</div>
			
			<!-----------------BreadCums -------------------->	
				<div class="Breadcumss">
					<div class="container">
						<nav aria-label="breadcrumb" role="navigation">
						  <ol class="breadcrumb">
						    <li class="breadcrumb-item"><a href="#">Home</a></li>
						    <li class="breadcrumb-item active" aria-current="page">Library</li>
						  </ol>
						</nav>
					</div>
				</div>