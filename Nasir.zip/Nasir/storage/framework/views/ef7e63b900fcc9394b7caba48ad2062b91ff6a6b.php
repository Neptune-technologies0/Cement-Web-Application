<!DOCTYPE html>
<html>
<head>
	<title>Web Applicaiton</title>

	<!----------------------Meta ------------------>
	
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<!------------------------------------------------------------------>

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
	
	<!------------------------------------------------------------------>


	<!----------------------Main Css ------------------>	
	<!---<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/main.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/Login.css')); ?>">
	<?php echo $__env->yieldContent('mycustomcss'); ?>
</head>
<body>
	<!-----------------Header Part -------------------->
	<header>
			<?php echo $__env->make("pages.mainNav", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</header>
	<!------Header Navigation ---->



	<!-----main-------->
	<main>
			<?php echo $__env->make("pages.Dashboardbreadcums", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->yieldContent('content'); ?>

	</main>
	<!------main End-------->
	<?php echo $__env->make("pages.footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->yieldContent('mycustomscripts'); ?>
	<script src="<?php echo e(asset('js/app.js')); ?>"></script>
	<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
</body>

</html>