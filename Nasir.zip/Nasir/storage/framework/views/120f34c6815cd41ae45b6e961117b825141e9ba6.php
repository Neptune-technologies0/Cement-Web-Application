			<div class="top-bar">
				<div class="container">
						<div class="logo pull-left">
							<img src="images/Logo.png" alt="LOGO" />
						</div>
						<div class="account-credentials pull-right">
							<ul>
								<li><a href="<?php echo e(route('login')); ?>">Login</a></li>
								<li><a href="<?php echo e(route('register')); ?>">Register</a></li>
							</ul>
						</div>
				</div>
			</div>