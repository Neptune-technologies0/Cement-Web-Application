<?php $__env->startSection('content'); ?>
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo e(csrf_field()); ?>

                    <div class="col-md-12">
                        <div class="login-form">
                            <h2><span>Nep</span>tech</h2>
                            
                           <div class="form-group">
                                          <label for="usr">Name:</label>
                                          <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                                            <?php if($errors->has('email')): ?>
                                                <span class="invalid-feedback">
                                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                            </div>
                            <div class="form-group">
                                          <label for="pwd">Password:</label>
                                          <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                            <?php if($errors->has('password')): ?>
                                                <span class="invalid-feedback">
                                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                            </div>
                            <div class="form-group">
                                    <div class="form-check">
                                        <label>
                                            <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> <span class="label-text">Remember me</span>
                                        </label>
                                    </div>
                            </div>

                            <div class="form-group">
                                          <button type="submit" class="btn btn-success btn-block">Login</button>
                            </div>                      
                    </div>
                </div>
            </form><!---form End---->
            <div class="forget-form">
                    <div class="col-md-12">
                            <a href="<?php echo e(route('password.request')); ?>">Forgot your password?</a>
                    </div>
            </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>