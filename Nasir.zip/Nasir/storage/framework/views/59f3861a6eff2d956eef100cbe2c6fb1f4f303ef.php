<!DOCTYPE html>
<html>
<head>
	<title>Web Applicaiton</title>

	<!----------------------Meta ------------------>
	
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<!------------------------------------------------------------------>

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/dataTables.bootstrap4.min.Css')); ?>">
	<!------------------------------------------------------------------>


	<!----------------------Main Css ------------------>	
	<!---<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/main.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/sale.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/DataTable.css')); ?>">

	<?php echo $__env->yieldContent('mycustomcss'); ?>
</head>
<body>
				<!-----------------Header Part -------------------->
				<header>
						<?php echo $__env->make("pages.mainNav", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</header>
				<!------Header Navigation ---->



				<!-----main-------->
				<main>
						<?php echo $__env->yieldContent('content'); ?>

				</main>
				<!------main End-------->
				<?php echo $__env->make("pages.footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				
	<script src="<?php echo e(asset('js/app.js')); ?>"></script>
	<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
	<?php echo $__env->yieldContent('mycustomscripts'); ?>
</body>

</html>